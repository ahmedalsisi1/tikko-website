
document.addEventListener('DOMContentLoaded', () => {
  const marquee = document.getElementById('prices-marquee');

  const coins = [
    { name: "BTC", price: "$64,200" },
    { name: "ETH", price: "$3,450" },
    { name: "BNB", price: "$585" },
    { name: "LUNC", price: "$0.000098" },
    { name: "PEPE", price: "$0.0000012" },
    { name: "SHIBA", price: "$0.000025" },
    { name: "TIKKO", price: "$0.83" }
  ];

  const tickerText = coins.map(c => `${c.name}: ${c.price}`).join(" ⬤ ");
  marquee.innerText = tickerText;
});
